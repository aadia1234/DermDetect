import SwiftUI
import AVKit


struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "scanner")
                .resizable()
                .imageScale(.medium)
                .foregroundColor(.accentColor)
                .frame(width: 170, height: 170)
            
            Spacer()
            
            Text("Welcome to DermDetect!")
                .font(.largeTitle)
            Spacer()
            Button("Scan your skin") {
                let image = UIImage(systemName: "globe")!
                let buffer = image.ciImage!.pixelBuffer!
                let prediction = Model.detect(buffer) ?? [:]
                
                print(prediction.count)
            }
            .font(.title)
        }.frame(width: 500, height: 350)
    }
}
