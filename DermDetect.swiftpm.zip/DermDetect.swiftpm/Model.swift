//
//  Model.swift
//  DermDetect
//
//  Created by Aadi Anand on 4/4/23.
//

import CoreML
import Vision

class Model {
    
    
    // buffer input
    static func detect(_ pixelBuffer: CVPixelBuffer) -> [String:Double]? {
        var prediction = [String:Double]()
                
        guard let model = try? VNCoreMLModel(for: DermDetectModel(configuration: MLModelConfiguration()).model) else {
            fatalError("Could not create model")
        }
        
        let request = VNCoreMLRequest(model: model) { output, error in
            let results = output.results as! [VNClassificationObservation]
            let firstPrediction = results.first!
            
            DispatchQueue.main.async {
                let disease: String = firstPrediction.identifier
                let confidence: Double = Double(firstPrediction.confidence * 100)
                
                prediction[disease] = confidence
                
                print("Disease: \(disease), Confidence: \(confidence)%")
            }
        }
        
        try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer).perform([request])
        
        return prediction
    }
    
    
    // tensor input
    
    static func detect(_ buffer)
}



/*
 
 output: String --> name of category
 
 input: Image () --> ResNet50
 
 */
